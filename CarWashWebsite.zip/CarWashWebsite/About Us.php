<?php
$title = "About Us";
$content = '<img src="Images/WASH1.jpg" class="imgLeft" />
<h3>About Us</h3>
<p>
    Welcome To EUGENE CAR WASH TM Franchises Head Office

Currently The Biggest And Most Successful Car Wash Franchise Group In South Africa
EUGENE CAR WASH TM Franchises was established 2022 by the founder who saw a very profitable market with room for improvement. After rigorous testing he moulded the EUGENE CAR WASH TM Franchises into what it is today.

The EUGENE CAR WASH TM Franchises works together like a close-knit family especially when it comes to finding innovative solutions, this has ensured our success.

Today we have understand the industry and we are the leader in the car wash franchise market in South Africa. Standing proud with our business concept that we manufactured and moulded into the success it is today.

Opening a EUGENE CAR WASH TM Franchises business is interesting, fun and is profitable. We currently have car washes set-up at mall’s, restaurants, industrial areas and so forth. This is a testament to the versatility of a car wash.

!!! OUR BRANCHES USE 80% LESS WATER AND ELECTRICITY THAN CONVENTIONAL CAR WASHES !!!

We will assist you with finding a site, building and setting up the premises, training of your staff, supplying your team with the right tools and knowledge to get the job done right, everytime.

EUGENE CAR WASH TM Franchises is The BEST, Reliable Service That You Can Count On.

EUGENE CAR WASH TM Franchises is the fastest growing brand that everyone is talking about.

WE ARE HERE TO HELP

We have sites available to build a start up car wash and valet centre and if we do not have a site in your area, we will find one for you.

Car Wash Franchises Available, Start Your Own Successful Car Wash Business Now.

Contact EUGENE CAR WASH TM Franchises Head Office, Join The Leading Car Wash Franchising Group.
BE YOUR OWN BOSS

DETERMINE YOUR OWN INCOME

BE IN CHARGE OF YOUR OWN BUDGET.
</p>

<img src="Images/WASH.jpg" class="imgRight"/>
<h3></h3>
<p>
    
</p>

<img src="Images/wash3.jpg" class="imgLeft" />
<h3></h3>
<p>
    
</p>';

include 'Template.php';
?>
