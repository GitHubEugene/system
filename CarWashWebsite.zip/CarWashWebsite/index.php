<?php
$title = "Home";
$content = '<img src="Images/WASH1.jpg" class="imgLeft" />
<h3>WELCOME</h3>
<p>
    Full Valet, Polishing and upholstery extraction cleaning done by THE idustry 
    professionals.EUGENE CAR WASH TM Franchises offer a superior car wash service 
    and experiencen fact, our service is so popular we have been franchising 
    since 2022. EUGENE CAR WASH TM Franchise provides a refreshingly up-market option
    to having your car washed. Our franchisees pride themselves in the 
    exceptional service they provide to their customers
</p>

<img src="Images/WASH.jpg" class="imgRight"/>
<h3>WHEELS & WAX</h3>
<p>
    Leave your paint job looking pristine and get your wheels in tip-top shape. 
    This is the ultimate achievement in suds and shine..
</p>

<img src="Images/wash3.jpg" class="imgLeft" />
<h3>WASH & DRY</h3>
<p>
    A super solid option that gets the job done. Give your car our standard power
    wash and dry, leaving your ride looking tidy and clean!.
</p>';

include 'Template.php';
?>
