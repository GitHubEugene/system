<?php
$title = "Contact";
$content = '<img src="Images/WASH1.jpg" class="imgLeft" />
<h3>Contact Us</h3>
<p>
    Got a question? Get in touch below.
</p>

<img src="Images/WASH.jpg" class="imgRight"/>
<h3></h3>
<p>
    Telephone: +27 606444154.
</p>

<img src="Images/wash3.jpg" class="imgLeft" />
<h3>Disclaimer</h3>
<p>
    Some pages on this site have affiliate links to products / services I recommend. 
    If you click on these links and buy the product/service, I might get a commission
    at no cost to you.
</p>';

include 'Template.php';
?>
